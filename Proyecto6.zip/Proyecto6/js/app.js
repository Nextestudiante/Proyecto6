window.onload=clics

var cifra1="";

function clics() {

	var n0=document.getElementById("0");
	n0.addEventListener("click",function() {
		clicEn("0");
		var num = ("0");
	})
	n0.addEventListener("mousedown", function(){
		n0.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n0.addEventListener("mouseout", function(){
		n0.setAttribute("style","transform:scale(1,1)")
	});

	var n1=document.getElementById("1");
	n1.addEventListener("click",function() {
		clicEn("1")
	})
	n1.addEventListener("mousedown", function(){
		n1.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n1.addEventListener("mouseout", function(){
		n1.setAttribute("style","transform:scale(1,1)")
	});

	var n2=document.getElementById("2");
	n2.addEventListener("click",function() {
		clicEn("2")
	})
	n2.addEventListener("mousedown", function(){
		n2.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n2.addEventListener("mouseout", function(){
		n2.setAttribute("style","transform:scale(1,1)")
	});

	var n3=document.getElementById("3");
	n3.addEventListener("click",function() {
		clicEn("3")
	})
	n3.addEventListener("mousedown", function(){
		n3.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n3.addEventListener("mouseout", function(){
		n3.setAttribute("style","transform:scale(1,1)")
	});

	var n4=document.getElementById("4");
	n4.addEventListener("click",function() {
		clicEn("4")
	})
	n4.addEventListener("mousedown", function(){
		n4.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n4.addEventListener("mouseout", function(){
		n4.setAttribute("style","transform:scale(1,1)")
	});

	var n5=document.getElementById("5");
	n5.addEventListener("click",function() {
		clicEn("5")
	})
	n5.addEventListener("mousedown", function(){
		n5.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n5.addEventListener("mouseout", function(){
		n5.setAttribute("style","transform:scale(1,1)")
	});

	var n6=document.getElementById("6");
	n6.addEventListener("click",function() {
		clicEn("6")
	})
	n6.addEventListener("mousedown", function(){
		n6.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n6.addEventListener("mouseout", function(){
		n6.setAttribute("style","transform:scale(1,1)")
	});

	var n7=document.getElementById("7");
	n7.addEventListener("click",function() {
		clicEn("7")
	})
	n7.addEventListener("mousedown", function(){
		n7.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n7.addEventListener("mouseout", function(){
		n7.setAttribute("style","transform:scale(1,1)")
	});

	var n8=document.getElementById("8");
	n8.addEventListener("click",function() {
		clicEn("8")
	})
	n8.addEventListener("mousedown", function(){
		n8.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n8.addEventListener("mouseout", function(){
		n8.setAttribute("style","transform:scale(1,1)")
	});

	var n9=document.getElementById("9");
	n9.addEventListener("click",function() {
		clicEn("9")
	})
	n9.addEventListener("mousedown", function(){
		n9.setAttribute("style","transform:scale(0.95,0.95)")
	})
	n9.addEventListener("mouseout", function(){
		n9.setAttribute("style","transform:scale(1,1)")
	});

	var mas=document.getElementById("mas");
	mas.addEventListener("click",function() {
		clicEn("+")
	})
	mas.addEventListener("mousedown", function(){
		mas.setAttribute("style","transform:scale(0.95,0.95)")
	})
	mas.addEventListener("mouseout", function(){
		mas.setAttribute("style","transform:scale(1,1)")
	});

	var menos=document.getElementById("menos");
	menos.addEventListener("click",function() {
		clicEn("-")
	})
	menos.addEventListener("mousedown", function(){
		menos.setAttribute("style","transform:scale(0.95,0.95)")
	})
	menos.addEventListener("mouseout", function(){
		menos.setAttribute("style","transform:scale(1,1)")
	});

	var por=document.getElementById("por");
	por.addEventListener("click",function() {
		clicEn("*")
	})
	por.addEventListener("mousedown", function(){
		por.setAttribute("style","transform:scale(0.95,0.95)")
	})
	por.addEventListener("mouseout", function(){
		por.setAttribute("style","transform:scale(1,1)")
	});

	var dividido=document.getElementById("dividido");
	dividido.addEventListener("click",function() {
		clicEn("/")
	})
	dividido.addEventListener("mousedown", function(){
		dividido.setAttribute("style","transform:scale(0.95,0.95)")
	})
	dividido.addEventListener("mouseout", function(){
		dividido.setAttribute("style","transform:scale(1,1)")
	});

	var punto=document.getElementById("punto");
	punto.addEventListener("click",function() {
		clicEn(".")
	})
	punto.addEventListener("mousedown", function(){
		punto.setAttribute("style","transform:scale(0.95,0.95)")
	})
	punto.addEventListener("mouseout", function(){
		punto.setAttribute("style","transform:scale(1,1)")
	});

	var igual=document.getElementById("igual");
	igual.addEventListener("click",calcular);
	igual.addEventListener("mousedown", function(){
		igual.setAttribute("style","transform:scale(0.95,0.95)")
	})
	igual.addEventListener("mouseout", function(){
		igual.setAttribute("style","transform:scale(1,1)")
	});

	var borrar=document.getElementById("on");
	borrar.addEventListener("click",eliminar);
	borrar.addEventListener("mousedown", function(){
		borrar.setAttribute("style","transform:scale(0.95,0.95)")
	})
	borrar.addEventListener("mouseout", function(){
		borrar.setAttribute("style","transform:scale(1,1)")
	});

	var cambiasigno=document.getElementById("sign");
	cambiasigno.addEventListener("click",camsig);
	cambiasigno.addEventListener("mousedown", function(){
		cambiasigno.setAttribute("style","transform:scale(0.95,0.95)")
	})
	cambiasigno.addEventListener("mouseout", function(){
		cambiasigno.setAttribute("style","transform:scale(1,1)")
	});

	var raiz=document.getElementById("raiz");
	raiz.addEventListener("click",raizc);
	raiz.addEventListener("mousedown", function(){
		raiz.setAttribute("style","transform:scale(0.95,0.95)")
	})
	raiz.addEventListener("mouseout", function(){
		raiz.setAttribute("style","transform:scale(1,1)")
	});
}


function clicEn(num){
	cifra1+=num
	var pan=document.getElementById("display");
	pan.innerHTML=cifra1;
}

function calcular()	{
	var rta=eval(cifra1);
	var pan=document.getElementById("display");
	pan.innerHTML=rta;
}

function eliminar(){
	var total= eval(cifra1="0")
	var pan=document.getElementById("display");
	pan.innerHTML=total;
}

function camsig()	{
	var cs=cifra1*(-1);
	var pan=document.getElementById("display");
	pan.innerHTML=cs;
	cifra1=cs;
}

function raizc()	{
	var rc=Math.sqrt(cifra1)
	var pan=document.getElementById("display");
	pan.innerHTML=rc;
	cifra1=rc;
}
